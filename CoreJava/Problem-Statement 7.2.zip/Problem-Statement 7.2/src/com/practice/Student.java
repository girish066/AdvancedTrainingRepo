package com.practice;

public class Student {

}
