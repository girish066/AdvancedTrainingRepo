package com.practice;

public abstract class Instrument {
	public abstract void play();
}
