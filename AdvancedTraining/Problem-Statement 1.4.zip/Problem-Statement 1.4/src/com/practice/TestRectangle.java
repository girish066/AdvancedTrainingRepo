package com.practice;

import java.util.Scanner;

public class TestRectangle {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
	System.out.println("Enter Length and breath:");
		
	Rectangle rect1=new Rectangle();
	rect1.setLength(sc.nextDouble());
	rect1.setWidth(sc.nextDouble());
	rect1.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	System.out.println("============================================");
	
	
	Rectangle rect2=new Rectangle();
	rect2.setLength(sc.nextDouble());
	rect2.setLength(sc.nextDouble());
	rect2.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	System.out.println("============================================");
	
	Rectangle rect3=new Rectangle();
	rect3.setLength(sc.nextDouble());
	rect3.setLength(sc.nextDouble());
	rect3.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	System.out.println("============================================");
	
	Rectangle rect4=new Rectangle();
	rect4.setLength(sc.nextDouble());
	rect4.setLength(sc.nextDouble());
	rect4.area();
	System.out.println("============================================");
	System.out.println("Enter Length and breath:");
	System.out.println("============================================");
	
	Rectangle rect5=new Rectangle();
	rect5.setLength(sc.nextDouble());
	rect5.setLength(sc.nextDouble());
	rect5.area();
	System.out.println("============================================");   
    
	    }

}
