package com.practice;

public class Book {
		
		private String book_title;
		private double book_price;
		public String getBook_title() {
			return book_title;
		}
		public void setBook_title(String book_title) {
			this.book_title = book_title;
		}
		public double getBook_price() {
			return book_price;
		}
		public void setBook_price(double book_price) {
			this.book_price = book_price;
		}
		public Book(String book_title, double book_price) {
			super();
			this.book_title = book_title;
			this.book_price = book_price;
		}
		public void showbook() {
			System.out.println("the book title is " +getBook_title()+",the price is "+getBook_price());
		}
		public static void main(String[] args) {
			Book[] obj=new Book[2];
			obj[0]=new Book(" Java Programming " , 350.50);
			obj[0].showbook();
			obj[1]=new Book(" c " , 200.00);
			obj[1].showbook();
			
		}
		
		
	
		
	

}
